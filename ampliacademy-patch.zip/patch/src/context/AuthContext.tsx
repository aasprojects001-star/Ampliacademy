import { createContext, useContext, useEffect, useState, ReactNode, useRef } from 'react'
import { User, Session } from '@supabase/supabase-js'
import { supabase } from '../lib/supabase'

interface Profile {
  id: string; email: string; full_name: string; avatar_url: string | null
  role: string; permissions: string[]; approved: boolean; position: string | null; bio: string | null
}

interface AuthContextType {
  user: User | null; session: Session | null; profile: Profile | null; loading: boolean
  signIn: (email: string, password: string) => Promise<{ error: any }>
  signUp: (email: string, password: string, fullName: string, intent?: string) => Promise<{ error: any }>
  signOut: () => Promise<void>; refreshProfile: () => Promise<void>
  hasPermission: (perm: string) => boolean; isCEO: () => boolean; isAdmin: () => boolean
  isMentor: () => boolean; isAmbassador: () => boolean; isTeamMember: () => boolean
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

function intentToRole(intent: string) {
  if (intent === 'ambassador') return 'campus_ambassador'
  if (intent === 'mentor') return 'mentor'
  return 'user'
}

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user,    setUser]    = useState<User | null>(null)
  const [session, setSession] = useState<Session | null>(null)
  const [profile, setProfile] = useState<Profile | null>(null)
  const [loading, setLoading] = useState(true)
  const fetchingRef = useRef(false)

  const fetchProfile = async (userId: string) => {
    // Guard against concurrent fetches (e.g. rapid token-refresh events)
    if (fetchingRef.current) return
    fetchingRef.current = true
    try {
      const { data } = await supabase.from('profiles').select('*').eq('id', userId).single()
      // FIX: only update profile state if data actually came back.
      // Previously, if the DB was slow and onAuthStateChange fired while the first
      // fetch was still running, profile could be set to null and the avatar would
      // revert to "U" (unknown) until the page was refreshed.
      if (data) setProfile(data)
    } catch {
      /* Profile row may not exist yet for brand-new signups — that's fine */
    } finally {
      fetchingRef.current = false
    }
  }

  useEffect(() => {
    // ── Initial session load ──────────────────────────────────────────────
    supabase.auth.getSession().then(({ data: { session } }) => {
      setSession(session)
      setUser(session?.user ?? null)
      if (session?.user) {
        // FIX: keep loading=true until profile arrives so ProtectedRoute never
        // flashes a redirect while the user is actually authenticated.
        fetchProfile(session.user.id).finally(() => setLoading(false))
      } else {
        setLoading(false)
      }
    })

    // ── Auth state listener ───────────────────────────────────────────────
    const { data: { subscription } } = supabase.auth.onAuthStateChange(async (event, session) => {
      setSession(session)
      setUser(session?.user ?? null)

      if (session?.user) {
        // FIX: Do NOT clear profile before fetching — clearing it causes the "U"
        // avatar flash. Existing profile data is still valid during a token refresh.
        await fetchProfile(session.user.id)
      } else {
        setProfile(null)
      }

      // Only update loading on SIGNED_IN / SIGNED_OUT, not on every TOKEN_REFRESHED
      if (event === 'SIGNED_IN' || event === 'SIGNED_OUT' || event === 'INITIAL_SESSION') {
        setLoading(false)
      }
    })

    return () => subscription.unsubscribe()
  }, [])

  const signIn = async (email: string, password: string) => {
    const { error } = await supabase.auth.signInWithPassword({ email, password })
    return { error }
  }

  const signUp = async (email: string, password: string, fullName: string, intent = 'academy') => {
    const role = intentToRole(intent)
    const { data, error } = await supabase.auth.signUp({ email, password, options: { data: { full_name: fullName } } })
    if (!error && data.user && role !== 'user') {
      setTimeout(async () => {
        await supabase.from('profiles').update({ role, full_name: fullName }).eq('id', data.user!.id)
      }, 2000)
    }
    return { error }
  }

  const signOut = async () => {
    setProfile(null)
    setUser(null)
    setSession(null)
    await supabase.auth.signOut()
  }

  const refreshProfile = async () => { if (user) await fetchProfile(user.id) }

  const hasPermission = (perm: string) => {
    if (!profile) return false
    if (['ceo', 'admin'].includes(profile.role)) return true
    return profile.permissions?.includes(perm) || false
  }

  const isCEO        = () => profile?.role === 'ceo'
  const isAdmin      = () => ['ceo', 'admin'].includes(profile?.role || '')
  const isMentor     = () => ['ceo', 'admin', 'mentor'].includes(profile?.role || '')
  const isAmbassador = () => profile?.role === 'campus_ambassador'
  const isTeamMember = () => ['ceo', 'admin', 'team_member'].includes(profile?.role || '')

  return (
    <AuthContext.Provider value={{ user, session, profile, loading, signIn, signUp, signOut, refreshProfile, hasPermission, isCEO, isAdmin, isMentor, isAmbassador, isTeamMember }}>
      {children}
    </AuthContext.Provider>
  )
}

export function useAuth() {
  const ctx = useContext(AuthContext)
  if (!ctx) throw new Error('useAuth must be used within AuthProvider')
  return ctx
}
